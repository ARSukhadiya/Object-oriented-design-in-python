from bank import Bank
from customers import Customer

class BankApp:
    def __init__(self) -> None:
        self.__bank = Bank("My Bank")
        self.__bank.get_customers_from_db()

    def show_title(self):
        pass

    def show_menu(self):
        print("===== MENU ====")
        print("1. Add Customer")
        print("2. Update Customer")
        print("7. Exit")

    def process_command(self, command) -> bool:
        cont = True
        if command == 1:
            self.__bank.add_customer()
        elif command == 2:
            self.__bank.update_customer()
        elif command == 7:
            cont = False
        return cont


def main():
    app = BankApp()
    app.show_title()

    cont = True
    while cont is True:
        app.show_menu()
        command = int(input("Enter your choice: "))
        cont = app.process_command(command)

if __name__ == "__main__":
    main()