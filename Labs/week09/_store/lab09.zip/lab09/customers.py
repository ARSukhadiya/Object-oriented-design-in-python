class Customer:
    def __init__(self, account_no: str, lastname: str, firstname: str, account_balance: float) -> None:
        self.__account_no = account_no
        self.__lastname = lastname
        self.__firstname = firstname
        self.__account_balance = account_balance

    def __str__(self) -> str:
        return f"account_no={self.__account_no}, lastname={self.__lastname}, firstname={self.__firstname}, balance={self.__account_balance}"

    def __repr__(self) -> str:
        return str(self)

    def __eq__(self, __value: object) -> bool:
        pass

    def convert_to_list(self) -> list[str]:
        lst = []
        lst.append(self.__account_no)
        lst.append(self.__lastname)
        lst.append(self.__firstname)
        lst.append(self.__account_balance)
        return lst

    


