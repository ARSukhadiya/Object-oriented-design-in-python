from customers import Customer
from customer_repos import CustomerRepository

class Bank:
    def __init__(self, bankname: str) -> None:
        self.__bankname = bankname
        self.__customers: list[Customer] = []

    def add_customer(self, customer):
        pass

    def update_customer(self, customer):
        pass

    def remove_customer(self, account_no):
        pass

    def get_customers_from_db(self):
        repos = CustomerRepository("customers.csv")
        self.__customers = repos.read_customers()

    def save_customers_to_db(self):
        repos = CustomerRepository("customers.csv")
        repos.save_customers(self.__customers)