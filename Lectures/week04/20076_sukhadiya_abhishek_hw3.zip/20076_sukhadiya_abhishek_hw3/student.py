# Program is not Completed / Done


class Gradebook:
    def __init__(self) -> None:
        self.__course_structure = {}
        self.__grade_calulation = None
        

class Student:
    def __init__(self, std_id: int, fname: str, lname: str) -> None:
        self.__std_id: int = std_id
        self.__fname: str = fname
        self.__lname: str = lname
        self.__grades: dict = {}

    def calculate_final_grade(self):
        pass


class Course:
    def __init__(self) -> None:
        pass

    def set_assessment_weights(self):
        pass


class GradePolicy:
    def __init__(self) -> None:
        self.__course_structure: dict = {}  # number and weights of assessments


def main():
    pass


if __name__ == "__main__":
    main()
